package aca.hankook.final20202296

class MovieC (var movieId : Int, var  movieNm : String, var movieRank : String, var movieTime : String, var movieRatings : String, var movieGrade : String, var movieDesc : String) {
}